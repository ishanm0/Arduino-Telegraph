# Arduino-Telegraph

This is a library for converting text, numbers, and certain punctuation symbols to Morse Code

Instructions taken from Arduino A Quick Start Guide Second Edition by Maik Schmidt.